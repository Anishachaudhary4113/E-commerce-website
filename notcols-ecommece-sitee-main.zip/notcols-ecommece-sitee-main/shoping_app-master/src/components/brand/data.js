import Img1 from "../../assets/images/img/asset 9.jpeg";
import Img2 from "../../assets/images/img/asset 10.jpeg";
import Img3 from "../../assets/images/img/asset 11.jpeg";
import Img4 from "../../assets/images/img/asset 12.jpeg";
import Img5 from "../../assets/images/img/asset 13.jpeg";
import Img6 from "../../assets/images/img/asset 14.jpeg";
import Img7 from "../../assets/images/img/asset 15.jpeg";
import Img8 from "../../assets/images/img/asset 16.jpeg";

export const brand = [
  {
    id: 1,
    imageUrl: Img1,
    name: "Apple",
  },
  {
    id: 2,
    imageUrl: Img2,
    name: "Samsung",
  },
  {
    id: 3,
    imageUrl: Img3,
    name: "oneplus",
  },
  {
    id: 4,
    imageUrl: Img4,
    name: "Google",
  },
  {
    id: 5,
    imageUrl: Img5,
    name: "Realme",
  },
  {
    id: 6,
    imageUrl: Img6,
    name: "Xiaomi",
  },
  {
    id: 7,
    imageUrl: Img7,
    name: "Oppo",
  },
  {
    id: 8,
    imageUrl: Img8,
    name: "Asus",
  },
];

export default brand;

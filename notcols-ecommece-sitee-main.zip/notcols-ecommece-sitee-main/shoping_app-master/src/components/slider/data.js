import Img1 from "../../assets/images/img/asset1.png";
import Img2 from "../../assets/images/img/asset3.png";
import Img3 from "../../assets/images/img/asset5.png";
import Img4 from "../../assets/images/img/asset7.png";
export const slides = [
  {
    ImageNo: "1/4",
    ImageName: "asset 1",
    ImageSrc: Img1,
  },
  {
    ImageNo: "2/4",
    ImageName: "asset 3",
    ImageSrc: Img2,
  },
  {
    ImageNo: "3/4",
    ImageName: "asset 5",
    ImageSrc: Img3,
  },
  {
    ImageNo: "4/4",
    ImageName: "asset 7",
    ImageSrc: Img4,
  },
];

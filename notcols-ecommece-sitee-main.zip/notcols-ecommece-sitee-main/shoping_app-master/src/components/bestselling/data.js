import Img1 from "../../assets/images/img/asset 21.png";
import Img2 from "../../assets/images/img/asset 22.png";
import Img3 from "../../assets/images/img/asset 23.png";
import Img4 from "../../assets/images/img/asset 24.png";
import Img5 from "../../assets/images/img/asset 25.png";
import Img6 from "../../assets/images/img/asset 26.png";
import Img7 from "../../assets/images/img/asset 27.jpeg";
import Img8 from "../../assets/images/img/asset 28.jpeg";

export const phone = [
  {
    id: 1,
    imageUrl: Img1,
    name: "Apple",
    price: 599,
  },
  {
    id: 2,
    imageUrl: Img2,
    name: "Samsung",
    price: 599,
  },
  {
    id: 3,
    imageUrl: Img3,
    name: "oneplus",
    price: 599,
  },
  {
    id: 4,
    imageUrl: Img4,
    name: "Google",
    price: 599,
  },
  {
    id: 5,
    imageUrl: Img5,
    name: "Realme",
    price: 599,
  },
  {
    id: 6,
    imageUrl: Img6,
    name: "Xiaomi",
    price: 599,
  },
  {
    id: 7,
    imageUrl: Img7,
    name: "Oppo",
    price: 599,
  },
  {
    id: 8,
    imageUrl: Img8,
    name: "Asus",
    price: 599,
  },
];

export default phone;

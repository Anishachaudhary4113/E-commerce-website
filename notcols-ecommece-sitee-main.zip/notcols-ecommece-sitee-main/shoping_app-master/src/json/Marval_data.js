import Img11 from "../assets/images/img/asset 33.png";
import Img12 from "../assets/images/img/asset 34.png";
import Img3 from "../assets/images/img/asset 35.png";
import Img4 from "../assets/images/img/asset 36.png";
import Img5 from "../assets/images/img/asset 37.png";
import Img6 from "../assets/images/img/asset 38.png";
import Img7 from "../assets/images/img/asset 39.png";
import Img8 from "../assets/images/img/asset 40.png";
import Img2 from "../assets/images/img/asset 31.png";
import Img1 from "../assets/images/img/asset 29.png";
import Img9 from "../assets/images/img/asset 41.png";
import Img10 from "../assets/images/img/asset 43.png";
import Img13 from "../assets/images/img/asset 45.png";
import Img14 from "../assets/images/img/asset 46.png";
import Img15 from "../assets/images/img/asset 47.png";
import Img16 from "../assets/images/img/asset 48.png";
import Img17 from "../assets/images/img/asset 49.png";
import Img18 from "../assets/images/img/asset 50.png";
import Img19 from "../assets/images/img/asset 51.png";
import Img20 from "../assets/images/img/asset 52.png";

export const marvel = [
  {
    id: 1,
    imageUrl: Img11,
    name: "Ironman Gaze",
    price: 599,
  },
  {
    id: 2,
    imageUrl: Img12,
    name: "Captain America Silhouette",
    price: 599,
  },
  {
    id: 3,
    imageUrl: Img3,
    name: "Dr Strange",
    price: 599,
  },
  {
    id: 4,
    imageUrl: Img4,
    name: "Marvel Fanfare",
    price: 599,
  },
  {
    id: 5,
    imageUrl: Img5,
    name: "Widow's Sting",
    price: 599,
  },
  {
    id: 6,
    imageUrl: Img6,
    name: "Avengers Monogram",
    price: 599,
  },
  {
    id: 7,
    imageUrl: Img7,
    name: "Wolverine On Bike",
    price: 599,
  },
  {
    id: 8,
    imageUrl: Img8,
    name: "Iron-Man in Action",
    price: 599,
  },
];
export const laptop = [
  {
    id: 1,
    imageUrl: Img13,
    name: "Ironman Gaze",
    price: 599,
  },
  {
    id: 2,
    imageUrl: Img14,
    name: "Captain America Silhouette",
    price: 599,
  },
  {
    id: 3,
    imageUrl: Img15,
    name: "Dr Strange",
    price: 599,
  },
  {
    id: 4,
    imageUrl: Img16,
    name: "Marvel Fanfare",
    price: 599,
  },
  {
    id: 5,
    imageUrl: Img17,
    name: "Widow's Sting",
    price: 599,
  },
  {
    id: 6,
    imageUrl: Img18,
    name: "Avengers Monogram",
    price: 599,
  },
  {
    id: 7,
    imageUrl: Img19,
    name: "Wolverine On Bike",
    price: 599,
  },
  {
    id: 8,
    imageUrl: Img20,
    name: "Iron-Man in Action",
    price: 599,
  },
];

export const slides = [
  {
    imageUrl: Img1,
    caption: "Slide 3",
  },
  {
    imageUrl: Img2,
    caption: "Slide 3",
  },
];
export const slides1 = [
  {
    imageUrl: Img9,
    caption: "Slide 3",
  },
  {
    imageUrl: Img10,
    caption: "Slide 3",
  },
];

module.export = { slides, marvel, laptop };
